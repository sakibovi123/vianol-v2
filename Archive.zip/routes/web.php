<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers;
use App\Http\Controllers\GalleryController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


// authentication routes
Route::get("/register", [ \App\Http\Controllers\auth\AuthController::class, "register_template" ])->name("register_template");
Route::post("/registration", [ \App\Http\Controllers\auth\AuthController::class, "register" ])->name("register");
Route::get("/login", [ \App\Http\Controllers\auth\AuthController::class, "login_template" ])->name("login_template");
Route::post("/login", [ \App\Http\Controllers\auth\AuthController::class, "login" ])->name("login");


Route::middleware(['auth'])->group(function () {
    // main route
    Route::get("/", [ App\Http\Controllers\DashboardController::class, "index" ])->name("main");

    // providers
    Route::get("/providers", [ App\Http\Controllers\SupplierController::class, "index" ])->name("providers");
    Route::get("/create-provider", [ App\Http\Controllers\SupplierController::class, "create" ])->name("create_provider");
    Route::get("/fetch-provider/{id}/", [ App\Http\Controllers\SupplierController::class, "show" ])->name("fetch_provider");
    Route::post("/save-provider", [ App\Http\Controllers\SupplierController::class, "store" ])->name("store_provider");
    Route::put("/update-provider/{id}/", [ \App\Http\Controllers\SupplierController::class, "update" ])->name("update_provider");
    Route::delete("/delete-prodiver/{id}/", [ \App\Http\Controllers\SupplierController::class, "destroy" ])->name("destroy_supplier");

    // Routes for gallery
    Route::get("/list-gallery", [ GalleryController::class, "index" ])->name("gallery_index");
    Route::get("/create-gallery", [ GalleryController::class, "create" ])->name("create_gallery");
    Route::get("/update-gallery/{id}/", [ GalleryController::class, "edit" ])->name("update_gallery");
});

