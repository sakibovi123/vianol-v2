$('#example').DataTable({
    language: {
        paginate: {
            next: '<button class="indicate mx-2">Next</button>',
            previous: '<button class="indicate">Back</button>'
        }
    },
    "bPaginate": true,
    "sPaginationType": "simple",
})
