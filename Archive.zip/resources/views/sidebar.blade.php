@include("base")
<!--Sidebar Start-->
<div class="left-menu">
    <div class="menubar-content">
        <nav class="animated bounceInDown">
            <ul id="sidebar">
                <li class="active">
                    <a href="{{ url('/') }}"><i class="bi bi-speedometer2"></i>Dashboard</a>
                </li>
                <li>
                    <a href=""><i class="bi bi-star"></i>Favourite</a>
                </li>
                <div class="ms-3 mt-3">
                    <span class="sidelink-title">
                        App Management
                    </span>
                </div>
                <li class="sub-menu">
                    <a href="#"><i class="bi bi-people-fill"></i>Suppliers
                        <div class="fas fa-caret-down right"></div>
                    </a>
                    <!--Sidebar dropdown-->
                    <ul class="left-menu-dp">
                        <li><a href="{{ route('providers') }}"><i class="bi bi-people-fill"></i>Suppliers</a></li>
                        <li><a href="{{ route('gallery_index') }}"><i class="bi bi-card-image"></i>Galleries</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="bi bi-folder"></i>Categories</a>
                </li>
                <li class="sub-menu">
                    <a href="#"><i class="bi bi-box-seam"></i>Products
                        <div class="fas fa-caret-down right"></div>
                    </a>
                    <!--Sidebar dropdown-->
                    <ul class="left-menu-dp">
                        <li><a href="#"><i class="bi bi-box-seam"></i>Products</a></li>
                        <li><a href="#"><i class="bi bi-chat-right-heart"></i>Reviews Products</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="#"><i class="bi bi-journal-text"></i>Reservations
                        <div class="fas fa-caret-down right"></div>
                    </a>
                    <!--Sidebar dropdown-->
                    <ul class="left-menu-dp">
                        <li><a href="#"><i class="bi bi-list-ul"></i>List Book Reservations</a></li>
                        <li><a href="#"><i class="bi bi-check-lg"></i>Checking Reservations</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="bi bi-person-circle"></i>Users</a>
                </li>
                <li class="sub-menu">
                    <a href="#"><i class="bi bi-question-circle"></i>FAQ
                        <div class="fas fa-caret-down right"></div>
                    </a>
                    <!--Sidebar dropdown-->
                    <ul class="left-menu-dp">
                        <li><a href="#"><i class="bi bi-folder"></i>Categories FAQ</a></li>
                        <li><a href="#"><i class="bi bi-question-circle"></i>The FAQ</a></li>
                    </ul>
                </li>
                <div class="ms-3 mt-3">
                    <span class="sidelink-title">
                        Settings
                    </span>
                </div>
                <li>
                    <a href="#"><i class="bi bi-images"></i>Media Library</a>
                </li>
            </ul>
        </nav>
    </div>
</div>
<!--Sidebar End-->