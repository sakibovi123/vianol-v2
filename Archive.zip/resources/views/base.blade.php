<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{ asset('css/bootstrap/bootstrap.min.css') }}">

    <!-- Customized CSS -->
    <link rel="stylesheet" href="{{ asset('css/sass.css') }}">
    <link rel="stylesheet" href="{{ asset('css/layout.css') }}">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">


    <!--Data table CSS-->
    <link rel="stylesheet" href="{{ asset('css/data-table/jquery.dataTables.css') }}" />

    <!-- Chart Css -->
    <link rel="stylesheet" href="{{ asset('css/chart/apexcharts.min.css') }}">

    <!-- Font awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- favicon Link-->
    <link rel="shortcut icon" href="{{ asset('img/admin.png') }}" type="image/x-icon">
    <script src="https://code.iconify.design/3/3.1.0/iconify.min.js"></script> 

    {{-- datatable links and scripts --}}
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
    {{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css"> --}}
    
    <script defer src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script defer src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script defer src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
    <script defer src="{{ asset('js/datatable.js') }}"></script>
    
    {{-- dropzone --}}
    <script src="https://unpkg.com/dropzone@5/dist/min/dropzone.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type="text/css" />

    <title>VIANOL ADMIN</title>
</head>
<body class="">


    {{-- @include("footer") --}}




