@include("sidebar")
@include("navbar")
@include("footer")
<div class="content-wrapper p-3">
    <div class="provider-container">
        <p>
            Supplier | Supplier Management
        </p>
        <div class="provider-container-links">
            <a href="#" class="links-div fs-6">
                <span class="iconify icn fs-4" data-icon="clarity:dashboard-line"></span>
                Dashboard
            </a>
            <p class="fs-6 mx-2">/</p>
            <a href="#" class="links-div fs-6">
                {{-- <span class="iconify icn fs-4" data-icon="clarity:dashboard-line"></span> --}}
                Providers
            </a>
        </div>
    </div>

    <div class="card-section shadow rounded">
        <div class="d-flex flex-column gap-2">
            <div class="menu-items-upper d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center gap-3">
                    <a href="" class="d-flex align-items-center gap-1">
                        <span class="iconify" data-icon="bi:list-task"></span>
                        Provider List
                    </a>
                    <a href="{{ route('create_provider') }}" class="d-flex align-items-center gap-1">
                        <span class="iconify" data-icon="mdi:create-new-folder"></span>
                        Create Provider
                    </a>
                </div>
            </div>
            <div class="border w-100 border-1"></div>
            @if ( $suppliers )
                
            
            <table id="example" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>City</th>
                        <th>Address</th>
                        <th>Landline Phone</th>
                        <th>Mobile Phone</th>
                        <th>Email</th>
                        <th>Creation Date</th>
                        {{-- <th>Mobile Phone</th> --}}
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($suppliers as $supplier)
                        <tr >
                            <td class="">
                                <div class="img-container bg-light rounded-circle shadow">
                                    <img src="{{ $supplier->image }}" class="object-fit-cover w-100" alt="">
                                </div>
                                
                            </td>
                            <td class="">{{ $supplier->name }}</td>
                            <td class="">{{ $supplier->city }}</td>
                            <td class="">{{ $supplier->address }}</td>
                            <td class="">{{ $supplier->landline_number }}</td>
                            <td class="">{{ $supplier->mobile_phone }}</td>
                            <td class="">{{ $supplier->email }}</td>
                            <td class="">{{ $supplier->created_at }}</td>
                            <td class="">
                                @if ($supplier->is_active == "Active")
                                    <p class="badge bg-success">Active</p>
                                @else
                                    <p class="badge bg-danger">CX</p>
                                @endif
                                
                            </td>
                            {{-- <td></td> --}}
                            <td class="d-flex" colspan="2">
                                <div class="">
                                    <a class="" href="{{ route('fetch_provider', $supplier->id) }}">
                                        <span class="iconify fs-4 text-primary" data-icon="mingcute:edit-line"></span>
                                    </a>
                                </div>
                                
                                <div class="">
                                    <form method="POST" class="h-100 d-flex col" action= "{{ route('destroy_supplier', $supplier->id) }}">
                                        @csrf
                                        @method("DELETE")
                                        <button type="submit" class="border-0 bg-transparent p-0">
                                            <span class="iconify fs-4 text-danger" data-icon="ph:trash"></span>
                                        </button>
                                    </form>
                                </div>
                                
                                
                            </td>
                        </tr>
                    @endforeach
                    
                
                </tbody>
                
            </table>
            @endif
        </div>
    </div>
    
</div>


