<?php echo $__env->make("sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper p-3">
    <div class="provider-container">
        <p>
            Supplier | Supplier Management
        </p>
        <div class="provider-container-links">
            <a href="#" class="links-div fs-6">
                <span class="iconify icn fs-4" data-icon="clarity:dashboard-line"></span>
                Dashboard
            </a>
            <p class="fs-6 mx-2">/</p>
            <a href="#" class="links-div fs-6">
                
                Providers
            </a>
        </div>
    </div>

    <div class="card-section shadow rounded">
        <div class="d-flex flex-column gap-2">
            <div class="menu-items-upper d-flex align-items-center justify-content-between">
                <div class="d-flex align-items-center gap-3">
                    <a href="" class="d-flex align-items-center gap-1">
                        <span class="iconify" data-icon="bi:list-task"></span>
                        Provider List
                    </a>
                    <a href="<?php echo e(route('create_provider')); ?>" class="d-flex align-items-center gap-1">
                        <span class="iconify" data-icon="mdi:create-new-folder"></span>
                        Create Provider
                    </a>
                </div>
            </div>
            <div class="border w-100 border-1"></div>
            <?php if( $suppliers ): ?>
                
            
            <table id="example" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>City</th>
                        <th>Address</th>
                        <th>Landline Phone</th>
                        <th>Mobile Phone</th>
                        <th>Email</th>
                        <th>Creation Date</th>
                        
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr >
                            <td class="">
                                <div class="img-container bg-light rounded-circle shadow">
                                    <img src="<?php echo e($supplier->image); ?>" class="object-fit-cover w-100" alt="">
                                </div>
                                
                            </td>
                            <td class=""><?php echo e($supplier->name); ?></td>
                            <td class=""><?php echo e($supplier->city); ?></td>
                            <td class=""><?php echo e($supplier->address); ?></td>
                            <td class=""><?php echo e($supplier->landline_number); ?></td>
                            <td class=""><?php echo e($supplier->mobile_phone); ?></td>
                            <td class=""><?php echo e($supplier->email); ?></td>
                            <td class=""><?php echo e($supplier->created_at); ?></td>
                            <td class="">
                                <?php if($supplier->is_active == "Active"): ?>
                                    <p class="badge bg-success">Active</p>
                                <?php else: ?>
                                    <p class="badge bg-danger">CX</p>
                                <?php endif; ?>
                                
                            </td>
                            
                            <td class="d-flex" colspan="2">
                                <div class="">
                                    <a class="" href="<?php echo e(route('fetch_provider', $supplier->id)); ?>">
                                        <span class="iconify fs-4 text-primary" data-icon="mingcute:edit-line"></span>
                                    </a>
                                </div>
                                
                                <div class="">
                                    <form method="POST" class="h-100 d-flex col" action= "<?php echo e(route('destroy_supplier', $supplier->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field("DELETE"); ?>
                                        <button type="submit" class="border-0 bg-transparent p-0">
                                            <span class="iconify fs-4 text-danger" data-icon="ph:trash"></span>
                                        </button>
                                    </form>
                                </div>
                                
                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                
                </tbody>
                
            </table>
            <?php endif; ?>
        </div>
    </div>
    
</div>


<?php /**PATH /Users/sakibovi/Desktop/Projects/Fiverr/vianol/resources/views/suppliers/index.blade.php ENDPATH**/ ?>