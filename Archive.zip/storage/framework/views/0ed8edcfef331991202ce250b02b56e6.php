<!-- Admin Dashboard End -->

<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

<!--  Bootstrap Bundle with Popper -->
<script src="<?php echo e(asset('js/bootstrap/bootstrap.bundle.min.js')); ?>"></script>

<!--Data table Js-->




<!--Chart plugins-->
<script src="<?php echo e(asset('js/chart/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/chart/chart.js')); ?>"></script>




<!-- Customized JavaScript -->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAl2eD9AfhycrlUccOZu-Kl_F8fV7N5doo&libraries=places&callback=initMap" async defer></script>
<script>
    let map;
    let autocomplete1;
    let autocomplete2;

    let directionsService;
    let directionsDisplay;


    function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
            zoom: 15
        });

        directionsService = new google.maps.DirectionsService();
        directionsDisplay = new google.maps.DirectionsRenderer();
        directionsDisplay.setMap(map);

        // Initialize Autocomplete for address inputs
        autocomplete1 = new google.maps.places.Autocomplete(
            document.getElementById('address')
        );
        // autocomplete2 = new google.maps.places.Autocomplete(
        //     document.getElementById('address2')
        // );

        // Get the user's current location
        getCurrentLocation();
    }

    function getCurrentLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                const userLocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };

                map.setCenter(userLocation);
                addMarker(userLocation, map);

                // setting longitude and latitude
                document.getElementById("latitude").value = position.coords.latitude;
                document.getElementById('longitude').value = position.coords.longitude;

                handleLocationSet();
            }, function(error) {
                console.error('Error getting user location:', error);
            });
        } else {
            console.error('Geolocation is not supported by this browser.');
        }
    }
    //
    function showMap() {
        const address1 = document.getElementById('address').value;
        console.log(address1)
        // const address2 = document.getElementById('address2').value;

        const geocoder = new google.maps.Geocoder();

        geocoder.geocode({ address: address1 }, (results, status) => {
            if (status === 'OK') {
                const location1 = results[0].geometry.location;
                addMarker(location1, map);
            } else {
                alert('Geocode was not successful for the following reason: ' + status);
            }
        });
    }

    function addMarker(location, map) {
        const marker = new google.maps.Marker({
            position: location,
            map: map
        });
        map.setCenter(location);
    }


</script>


</body>
</html>
<?php /**PATH /Users/sakibovi/Desktop/Projects/Fiverr/vianol/resources/views/footer.blade.php ENDPATH**/ ?>